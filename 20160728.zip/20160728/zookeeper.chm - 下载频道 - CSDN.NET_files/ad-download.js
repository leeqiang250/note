var ad_type = 'js1614';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
//document.writeln(ad_sc);
/*
ad_type = 'ms1571_2';
ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

ad_type = 'ms1577_3';
ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

ad_type = 'ms1558_4';
ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

ad_type = 'ms1326_5';
ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
*/