define( function () {
  function asyRequest( conf, callback ) {
    $.ajax( {
      type: conf.type || 'GET',
      url: conf.url,
      data: conf.data || {},
      dataType: conf.dataType || 'jsonp',
      success: function ( data ) {
        typeof callback === 'function' && callback.call( callback, data );
      }
    } );
  }

  function asyProxy( proxyUrl, data, callback ) {
    $( '<iframe src="' + proxyUrl + '" style="display:none">' ).load( function () {
      // var success = data.success;
      data.success = function ( dt ) {
        typeof callback === 'function' && callback.call( callback, dt.hits );
      };
      this.contentWindow.jQuery.ajax( data );
    } ).prependTo( 'body' );
  }

  return {
    run: asyRequest,
    proxy: asyProxy
  }
} );