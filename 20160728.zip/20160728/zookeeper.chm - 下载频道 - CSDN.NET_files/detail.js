jQuery(function($) {
  var fixedLayer, tagSwitch;
  (fixedLayer = function() {
    if ($(window).scrollTop() > $('.information .operating').map(function() {
      return $(this).offset().top - 23;
    })[0]) {
      return $('.fix-layer').fadeIn();
    } else {
      return $('.fix-layer').fadeOut();
    }
  })();
  $(window).scroll(function() {
    clearTimeout(fixedLayer.timer);
    return fixedLayer.timer = setTimeout(fixedLayer, 50);
  });
  (tagSwitch = function(t) {
    return $('.tab-switch .tab-layer').children().hide().eq($(t).index()).show();
  })($('.tab-switch .tabs a.active'));
  $('.tab-switch .tabs a').click(function() {
    $(this).addClass('active').siblings().removeClass('active');
    tagSwitch(this);
    return false;
  });
  return $('.collect-tip .close').click(function() {
    return $('.collect-tip').hide();
  });
});
