define( ['apps/load.list'], function ( list ) {
  function run( key ) {
    return getConf( key );
  }

  function getConf( key ) {
    var Conf = {
      // 加载TAB的配置信息
      loadTabs: {
        url: 'http://so.csdn.net/so/search/so/autoMatch.do',
        data: ( function () {
          var data = [];
          var $title = $( '.article' ).find( '.title' );
          var $tags = $( '.tags-share' ).find( '.tag' );

          data.push( $title.attr( 'title' ) );
          $tags.each( function ( i, tag ) {
            data.push( $( tag ).html() );
          } );

          return {
            q: data.join( ',' ),
            size: 4
          }
        } )()
      },

      // 加载TAB对应内容的配置信息
      loadContentList: {
        // url: 'http://search.dm.csdn.net/v2/pro_download/csdn/_search?_client_=so_search',
        url: 'http://internalapi.csdn.net/psearch/psearch/query?index_name=pro_download&_client_=so_search',
        headers: {
            'X-acl-token':'GZKKC7fu8XYXEMPGvSeJG6FucAMK'
        },
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: {
          "from": 0,
          "size": 5,
          "fields": [
            'id',
            'url',
            'type',
            'title',
            'created_at',
            'user_name',
            'nick_name',
            'views',
            'desc',
            'categoryid',
            'channel_id',
            'comment_score',
            'filetype',
            'sourcescore',
            'sourcesize',
            'type'
          ]
        }
      }
    };

    return Conf[ key ];
  }

  return {
    run: run
  }
} );
