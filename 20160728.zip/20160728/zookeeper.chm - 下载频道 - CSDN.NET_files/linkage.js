var Linkage = ( function () {
  var provCityData;
  
  function init ( prov, city ) {
    var $prov = $( prov );
    var $city = $( city );

    asyGetData( {}, function ( data ) {	  
      provCityData = createJsonData( data );

      setProvince( provCityData, $prov );
      $city.append( '<option value="0">请选择</option>' );
      industry( data );
      bindEvent( $prov, $city, provCityData );
    } );
  };

  // 级联的事件绑定
  function bindEvent ( $prov, $city, data ) {
    $prov.bind( 'change', function () {
      var value = $( this ).val();
      setCity( {
		  value: value, 
		  data: data, 
		  $city: $city
	  } );
    } );
  };

  // 设置省
  function setProvince ( data, $prov ) {
    var province = data.province;
    $prov.append( '<option value="0">请选择</option>' );
    for ( var key in province )
    {
      $prov.append( '<option value="'+ key +'">'+ province[ key ] +'</option>' );
    }
  };

  // 设置市
  function setCity ( conf ) {
    var city = conf.data.city;
    var value = conf.value;
    var arr;

    conf.$city.empty();
    conf.$city.append( '<option value="0">请选择</option>' );
    for ( var i = 0, l = city[ value ].length; i < l; i++ )
    {
      arr = city[ value ][ i ].split( ':' );
      conf.$city.append( '<option value="'+ arr[ 0 ] +'">'+ arr[ 1 ] +'</option>' );
    }
    typeof conf.callback === 'function' && conf.callback();
  };

  // 重新组建JSON数据
  function createJsonData ( data ) {
    var data = data.result.provinceCity;
    var Province = {}, City = {};
    var provKey = /([0]{4})$/, cityKey = /^(\d{2})/;
    var tempProv, tempCity, reg, cities = [], provs = [];

    // 匹配省
    for ( var key in data )
    {
      if ( provKey.test( key ) )
      {
        Province[ key ] = data[ key ];
        provs.push( key );
      }
      else
      {
        cities.push( key );
      }
    }

    // 匹配市
    for ( var i = 0, l = provs.length; i < l; i++ )
    {
      var cityInProvs = [];
      if ( cityKey.test( provs[ i ] ) )
      {
        tempProv = RegExp.$1;
        reg = new RegExp( '^' + tempProv );
      }
      for ( var k = 0, len = cities.length; k < len; k++ )
      {
        if ( reg.test( cities[ k ] ) )
        {
          cityInProvs.push( cities[ k ] + ':' + data[ cities[ k ] ] );
        }
      }
      City[ provs[ i ] ] = cityInProvs;
    }
    return {
      province: Province,
      city: City
    }
  };
  
  function industry ( data ) {
	  var $industry = $( '#industry' );
	  var industry = data.result.industrytype;
	  
	  $industry.width( '244px' );
	  $industry.append( '<option value="0">请选择</option>' );
	  for ( var key in industry )
	  {
		  $industry.append( '<option value="'+ key +'">'+ industry[ key ] +'</option>' );
	  }
  };
  
  function reset ( value, $city, callback ) {
      $city.empty();
      $city.append( '<option value="0">请选择</option>' );
	  setCity( {
		  value: value, 
		  data: provCityData, 
		  $city: $city, 
		  callback: callback
	  } );
  };

  // 请求原始JSON数据
  function asyGetData ( data, callback ) {
    $.ajax( {
      url: '/js/metadata.json',
      type: 'GET',
      data: data || '',
      dataType: 'json',
      success: function ( data ) {
        typeof callback == 'function' && callback( data );
      }
    } );
  };

  return {
    init: init,
    reset: reset
  }
} )();
