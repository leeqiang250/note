requirejs.config( {
  baseUrl: '.',
  paths: {
    apps: '/js/apps',
    libs: '/js/libs'
  }
} );

requirejs( ['apps/switch.tabs'], function ( tab ) {
  tab.run();
} );
