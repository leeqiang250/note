define( ['apps/asyRequest', 'apps/getConfiger', 'apps/tabSwitch', 'apps/load.list'], function ( asy, confs, tabSwitch, list ) {
  var $temp;

  function run() {
    bindEvent();
  }

  function bindEvent() {
    // 加载TAB标签
    loadTabs( 'loadTabs', function ( dt ) {
      var sugg = dt.suggestions, link, active;
      var $tabs = $( '.tabs' );
      var $tabLayers = $( '.tab-layer' );
      var $ul, load;

      if ( sugg.length > 0 )
      {
        $tabs.empty();
        $tabLayers.empty();
        for ( var i = 0, l = sugg.length; i < l; i++ )
        {
          if ( i === 0 )
          {
            load = sugg[i].key;
            link = '<a href="#" class="active" title="'+ sugg[i].key+'">'+ sugg[i].substr_key +'</a>';
          }
          else
          {
            link = '<a href="#" title="'+ sugg[i].key+'">'+ sugg[i].substr_key +'</a>';
          }
          $tabs.append( link );
        }
        $temp = $tabs.find( 'a:first' );
        loadData( load );
      }
      else
      {
        $tabs.parent().remove();
      }
    } );

    // 显示TAB标签对应的内容
    tabSwitch.run( function ( $target ) {
      var st = $target.html();

      $temp && $temp.removeClass();
      $target.addClass( 'active' );
      $temp = $target;
      loadData( st );
    } );
  }

  function loadData( st ) {
    var data = {
      "query": {
        "text": {
          "title,body": st
        }
      }
    };
    conf = mergeQueryConfig( data );
    conf.data = JSON.stringify( conf.data );
    asyProxyContent( conf, function ( data ) {
      var $root = $( '.tab-layer' );
      list.run( $root, data, st );
    } );
  }

  function mergeQueryConfig( data ) {
    var contentConf = confs.run( 'loadContentList' );
    $.extend( contentConf.data, data );
    return contentConf;
  }

  // 页面初始化TAB
  function loadTabs( key, callback ) {
    var conf = confs.run( key );
    asy.run( conf, callback )
  }

  // 切换TAB显示对应内容
  function asyProxyContent( conf, callback ) {
    asy.proxy( 'http://internalapi.csdn.net/proxy.html', conf, callback );
  }

  return {
    run: run
  }
} );