<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<title>Proxy error: 504 Connect to download.csdn.net:80 failed: Connection reset by client.</title>
</head><body>
<h1>504 Connect to download.csdn.net:80 failed: Connection reset by client</h1>
<p>The following error occurred while trying to access <strong>http://download.csdn.net/js/text-stretch.js</strong>:<br><br>
<strong>504 Connect to download.csdn.net:80 failed: Connection reset by client</strong></p>
<hr>Generated Wed, 27 Jul 2016 13:13:05 GMT by Polipo on <em>leeqiangWindows:8123</em>.
</body></html>
