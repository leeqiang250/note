/*��������*/
var setpageview_showing = true;
(function () {
    function hexunOutTimer(yr_n, mt_n, dt_n, hr_n, mn_n) {
        var temp_date = new Date();
        if (yr_n != null) {
            temp_date.setYear(yr_n);
        }
        if (mt_n != null) {
            temp_date.setMonth(mt_n - 1);
        }
        if (dt_n != null) {
            temp_date.setDate(dt_n);
        }
        if (hr_n != null) {
            temp_date.setHours(hr_n);
        }
        if (mn_n != null) {
            temp_date.setMinutes(mn_n);
        }
        return temp_date;
    }

    var dataNow = new Date();

    function flowdomwrite(n, arr) {
        var tempflowArray = new Array();
        var pd = /hexun/;
        switch (n) {
            case 1: //500w-600w---400W
                pd = /hexun/;
                break;
            case 2: //300w-500w
                pd = /news|stock|gold|funds|tech|blog|futures|auto|house|lux|money|book|shoucang|forex/;
                break;
            case 3: //100w-150w
                pd = /news|stock|blog/;
                break;
            default:
        }
        if (pd.test(location.href)) {
            for (var i = 0; i < arr.length; i++) {
                tempflowArray.push(arr[i]);
            }
        }
        if (tempflowArray == "") return;
        document.write('<div style="height:1px;overflow:hidden"><div style="margin-top:1px" class="flowtimer">' + tempflowArray.join('') + '</div></div>');
        tempAdvArray = null;
    }

    var flowTimer1 = {
        s: hexunOutTimer(2016, 5, 26, 7, 30),
        e: hexunOutTimer(2016, 8, 13, 8, 00)
    };
    var flowTimer2 = {
        s: hexunOutTimer(2016, 3, 23, 8, 00),
        e: hexunOutTimer(2016, 7, 29, 8, 00)
    };
    var flowTimer3 = {
        s: hexunOutTimer(2016, 5, 9, 8, 00),
        e: hexunOutTimer(2016, 7, 30, 8, 00)
    };
    var flowTimer4 = {
        s: hexunOutTimer(2016, 4, 1, 8, 00),
        e: hexunOutTimer(2016, 7, 30, 8, 00)
    };
    var flowTimer5 = {
        s: hexunOutTimer(2016, 4, 1, 8, 00),
        e: hexunOutTimer(2016, 7, 29, 8, 00)
    };


    if (dataNow >= flowTimer1.s && dataNow <= flowTimer1.e) {
        var flowarr = [];
        flowarr.push('<iframe width="1000" height="60" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://hxsame.hexun.com/s?z=hexun&c=1694&op=1" ></iframe>');//��Ʊ����ҳһͨ��
        flowdomwrite(1, flowarr);
        flowarr = null;
    }
    if (dataNow >= flowTimer2.s && dataNow <= flowTimer2.e) {
        var flowarr = [];
        flowarr.push('<iframe width="300" height="250" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://hxsame.hexun.com/s?z=hexun&c=1838&op=1" ></iframe>');//�����㣬�����������Ķ�

        flowdomwrite(1, flowarr);
        flowarr = null;
    }
    if (dataNow >= flowTimer3.s && dataNow <= flowTimer3.e) {
        var flowarr = [];
        flowarr.push('<iframe width="1000" height="90" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://hxsame.hexun.com/s?z=hexun&c=1376&op=1" ></iframe>');//�ַ����У�������ҳһͨ��
        flowdomwrite(1, flowarr);
        flowarr = null;
    }
    if (dataNow >= flowTimer4.s && dataNow <= flowTimer4.e) {
        var flowarr = [];
        flowarr.push('<iframe width="100" height="100" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://hxsame.hexun.com/s?z=hexun&c=1981&op=1" ></iframe>'); //�Ϻ�ũ���У�������ҳ������ť��
        flowdomwrite(2, flowarr);
        flowarr = null;
    }
    if (dataNow >= flowTimer5.s && dataNow <= flowTimer5.e) {
        var flowarr = [];
        flowarr.push('<iframe width="300" height="60" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://hxsame.hexun.com/s?z=hexun&c=482&op=1" ></iframe>');//�ַ����У�������ҳ��һ��ť
        flowdomwrite(2, flowarr);
        flowarr = null;
    }
})()