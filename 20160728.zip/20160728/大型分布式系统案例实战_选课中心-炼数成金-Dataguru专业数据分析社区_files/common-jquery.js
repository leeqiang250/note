jQuery(function(){
	// ����
	jQuery(".nav li").hover(function(){
		var leng = jQuery(this).find(".subnav").length;
		if(leng>0){
			jQuery(this).find(".subnav").show();
		}
	},function(){
		jQuery(this).find(".subnav").hide();
	});
	//����
	jQuery(".input-t input").focus(function(){
		jQuery(this).val("");
		jQuery(this).parents(".search-box-c").animate({"width":123},300);
	}).blur(function(){
		jQuery(this).val(this.defaultValue);
		jQuery(this).parents(".search-box-c").animate({"width":55},300);
	});
	// ��ݵ���
	jQuery(".kjnav").hover(function(){
		jQuery("#kjnav_box").show();
	},function(){
		jQuery("#kjnav_box").hide();
	})
	//����ϲ��
	jQuery(".list-item").hover(function(){
		var h1 = jQuery(this).find(".list-info-text").height();
		var h2 = jQuery(this).find(".list-info-btn:last").height();
		jQuery(this).find(".list-info-text").show();
		jQuery(this).find(".list-info-btn:last").show();
		jQuery(this).find(".list-info").css("zIndex","100").height(h1+h2+84);
	},
	function(){
		jQuery(this).find(".list-info-text").hide();
		jQuery(this).find(".list-info-btn:last").hide();
		jQuery(this).find(".list-info").css("zIndex","0").height(64);
	});
	//�γ�רҵ
		jQuery(".list-zy").hover(function(){
			var h1 = jQuery(this).find(".list-info-text").height();
			var h2 = jQuery(this).find(".list-info-fun:last").height();
			jQuery(this).find(".list-info-text").show();
			jQuery(this).find(".list-info-fun:last").show();
			jQuery(this).find(".list-info-fun:first").hide();
			jQuery(this).find(".list-info").css("zIndex","100").height(h1+h2+44);
		},
		function(){
			jQuery(this).find(".list-info-text").hide();
			jQuery(this).find(".list-info-fun:last").hide();
			jQuery(this).find(".list-info-fun:first").show();
			jQuery(this).find(".list-info").css("zIndex","0").height(64);
		});
	// רҵ��·ͼ
	jQuery(".list-ltem-m li").hover(function(){
		var h = jQuery(this).find(".list-ltem-text").height();
		jQuery(this).find(".list-ltem-text").show();
		jQuery(this).find(".list-ltem-info").css("zIndex","100").height(h+70);
	},
	function(){
		jQuery(this).find(".list-ltem-text").hide();
		jQuery(this).find(".list-ltem-info").css("zIndex","0").height(56);
	});
	// tablist
	/*jQuery(".tablist a").each(function(){
		jQuery(this).click(function(e){
			e.preventDefault();
			jQuery(this).addClass("hover").siblings().removeClass("hover");
		});
	});*/
});	
