<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<title>Proxy error: 502 Server dropped connection.</title>
</head><body>
<h1>502 Server dropped connection</h1>
<p>The following error occurred while trying to access <strong>http://trust.baidu.com/vcard/v.js?siteid=2259294&amp;url=http%3A%2F%2Fwww.dataguru.cn%2Fcourse-131.html&amp;source=https%3A%2F%2Fwww.google.co.jp%2F&amp;rnd=1205887214&amp;hm=1</strong>:<br><br>
<strong>502 Server dropped connection</strong></p>
<hr>Generated Tue, 26 Jul 2016 14:01:49 GMT by Polipo on <em>leeqiangWindows:8123</em>.
</body></html>
