var node=document.getElementById('cnzz_stat_icon_'+4902471);
if(node){
    node.innerHTML="<a href=http://www.cnzz.com/stat/website.php?web_id=4902471 target=_blank>站长统计</a>";
}else{
    document.write("<a href=http://www.cnzz.com/stat/website.php?web_id=4902471 target=_blank>站长统计</a>");
}