HelloPanoramaGL
===============

PanoramaGL 全景展示

fix warnings in XCode 5

use CMMotionManager replace UIAccelerometer

add Accelerometer Effect

对官方例子稍加修改 去除xcode5上的警告 

对重力感应做了向下兼容

添加了重力感应效果
