#import <Foundation/Foundation.h>
#import "XMPPPresence.h"

@interface XMPPPresence (XEP_0172)

- (NSString *)nick;

@end
