
#import "NSXMLElement+XMPP.h"

@interface NSXMLElement (XEP0352)

+ (instancetype)indicateInactiveElement;
+ (instancetype)indicateActiveElement;

@end
