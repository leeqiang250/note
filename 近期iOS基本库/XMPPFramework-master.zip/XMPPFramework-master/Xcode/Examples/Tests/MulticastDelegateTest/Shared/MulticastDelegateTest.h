#import <Foundation/Foundation.h>


@interface MulticastDelegateTest : NSObject

+ (MulticastDelegateTest *)sharedInstance;

- (void)test;

@end
