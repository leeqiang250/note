//
//  main.m
//  iPhoneXMPP
//
//  Created by Robbie Hanson on 3/18/10.
//  Copyright Deusty, LLC 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
